(
    () => {
        const ctx = document.getElementById('chart').getContext('2d');
        ctx.moveTo(0,0);
        ctx.lineTo(200,100);
        ctx.stroke();
    }
)();

