
sp <- ggplot(mtcars, aes(x=wt, y=mpg)) + geom_point(shape=2)
sp
sp + facet_grid(vs ~ cyl)
sp + facet_wrap( ~ cyl)
mtcars
