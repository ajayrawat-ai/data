
library(stringr)
library(maps)

states<-as.data.frame(state.x77)
states$region <- tolower(rownames(states))

states_map <- map_data("state")
fact_join <- left_join(states_map, states, by = "region")
ggplot(fact_join, aes(long, lat, group = group))+
  geom_polygon(aes(fill = Illiteracy), color = "white")+
  scale_fill_viridis_c(option = "C")
