
ToothGrowth$dose <-as.factor(ToothGrowth$dose)
# Basic barplot
p<-ggplot(data=ToothGrowth, aes(fill=supp,x=dose, y=len)) +
  geom_bar(position="dodge",stat="identity")
p

# Horizontal bar plot
p + coord_flip()

