mtcars$am <-as.factor(mtcars$am)

sm<- ggpairs(mtcars, columns = 1:4, title = "MT Cars",  
        mapping=ggplot2::aes(colour = am), axisLabels = "show")
sm
