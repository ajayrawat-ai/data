

### Formatting ggplot2 Visualization Elements in R

##Module: Understanding a Ggplot2 Setup

library(ggplot2)

# General Setup
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point(size = 0.5) +
  geom_smooth(col = "red") +
  geom_vline(xintercept = 10000,
             col = "green", lwd = 2.7) +
  ggtitle(lab = "My First Ggplot")

# Reference page: https://ggplot2.tidyverse.org/reference/


# Adding titles - ggtitle or labs
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  ggtitle(label = "Diamond Prices by Weight",
          subtitle = "Carat as Standard Weight Unit of Diamonds")

ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  labs(title = "Diamond Prices by Weight",
       subtitle = "Carat as Standard Weight Unit of Diamonds",
       caption = "1 Carat = 200 mg = 0.00705 oz",
       tag = "Location Australia")

# Line break in subtitle
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  ggtitle(label = "Diamond Prices by Weight",
          subtitle = "Carat as Standard\nWeight Unit of Diamonds")


# Using pre-defined themes
ggplot(diamonds, aes(x=cut, y=price)) +
  geom_boxplot() +
  theme_bw()

ggplot(diamonds, aes(x=cut, y=price)) +
  geom_boxplot() +
  theme_dark()

ggplot(diamonds, aes(x=cut, y=price)) +
  geom_boxplot() +
  theme_void()

# Using ggthemes
library(ggthemes)
ggplot(diamonds, aes(x=cut, y=price)) +
  geom_boxplot() +
  theme_gdocs()


# Facette methods
library(lattice)

# Facet wrap example
ggplot(diamonds, aes(x = clarity, fill = cut)) + 
  geom_bar(stat = "count", position = 'stack') + 
  facet_wrap(~color, nrow = 2) + 
  xlab("") +
  theme(axis.text.x = element_text(angle = 90,
                                   hjust = 1,
                                   size = 8), 
        legend.position = "bottom")

# Facet grid example
ggplot(diamonds, aes(x = clarity, fill = cut)) + 
  geom_bar(stat = "count", position = 'stack') + 
  facet_grid(~color) + 
  xlab("") +
  theme(axis.text.x = element_text(angle = 90,
                                   hjust = 1,
                                   size = 8), 
        legend.position = "bottom")

# Discretizing
x = cut_interval(diamonds$carat, 10)
plot(x, las = 2)
x = cut_number(diamonds$carat, 10)
plot(x, las = 2)









## Module: Changing Default Color Settings

# manual setting
ggplot(diamonds, aes(x=price, y=carat, color=cut)) +
  geom_point() +
  scale_color_manual(values = c("Fair" = "black", 
                                "Good" = "red", 
                                "Very Good" = "blue",
                                "Premium" = "green",
                                "Ideal" = "yellow")) 

# Using the ColorBrewer palettes
ggplot(diamonds, aes(x=price, y=carat, color=cut)) +
  geom_point() +
  scale_color_brewer(palette = "Dark2")

ggplot(diamonds, aes(x=price, y=carat, color=cut)) +
  geom_point() +
  scale_color_brewer(type = "seq")

# ColorSpace
hcl_palettes(plot = T)

demoplot(qualitative_hcl(4, "Dynamic"),
         type = "bar")

ggplot(diamonds, aes(x=price, y=carat, color = cut)) +
  geom_point() +
  scale_color_discrete_sequential()

# Difference between the fill and color aesthetic
ggplot(diamonds, aes(x = clarity, fill = cut)) + 
  geom_bar(stat = "count", position = 'stack') +
  scale_fill_brewer(palette = "BrBG")

ggplot(diamonds, aes(x = clarity, color = cut)) + 
  geom_bar(stat = "count", position = 'stack') +
  scale_color_brewer(palette = "BrBG")

# Shading effect, interesting for numeric data
ggplot(diamonds, aes(x = clarity, alpha = cut)) + 
  geom_bar(stat = "count", position = 'stack') +
  scale_alpha_discrete(range = c(0.2, 0.9))


# 2 categorical aesthetics in one point, use points with ID 21-25
ggplot(diamonds[1:50, ],
       aes(x=price, y=carat,
           colour=cut, fill=clarity)) +
  geom_point(shape = 21, size = 5, stroke = 3) +
  scale_colour_brewer(palette = "Set1")+
  scale_fill_brewer(palette = "Accent")









## Module: Working on Plot Axes

# Breaks
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_continuous(name = "Price in USD", 
                     breaks = c(5000, 10000), 
                     position = "top")


# Labels
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_continuous(name = "Price in USD", 
                     breaks = c(5000, 10000),
                     labels = c("A", "B"),
                     position = "top")


# Argument limits
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_continuous(name = "Price in USD", 
                     limits = c(5000, 10000),
                     position = "top")


# Using xlim
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  xlim(5000, 10000)


# Modifying both scales
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_continuous(name = "Price in USD", 
                     limits = c(5000, 10000),
                     position = "top") +
  scale_y_continuous(name = "",
                     breaks = c(1, 2),
                     labels = c("Low", "High"),
                     position = "right")




# Scales in categorical data

# Rename levels
ggplot(diamonds, aes(cut, price)) + 
  geom_boxplot() + 
  coord_flip() +
  scale_x_discrete(labels = c("Fair" = "F",
                              "Good" = "G",
                              "Very Good" = "VG",
                              "Premium" = "P",
                              "Ideal" = "I"))
  
# Label abbreviations
ggplot(diamonds, aes(cut, price)) + 
  geom_boxplot() + 
  scale_x_discrete(labels = abbreviate)



# Specify the limits
ggplot(diamonds, aes(cut, price)) + 
  geom_boxplot() +
  xlim("Ideal", "Good") +
  ylim(3000, 6000)


# Axis titles

ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point(aes(colour = cut)) +
  xlab(label = "Price")

ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point(aes(colour = cut)) +
  xlab(label = "Price") +
  theme(axis.title.x = element_text(hjust=0.9))



# Scale orientation
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_reverse()


# Scale transformations
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_log10()

ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_x_continuous(trans = "log1p")


# Secondary Axis

# Simple axis duplicate
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_y_continuous(sec.axis = dup_axis())
  
# Secondary axis with different units
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point() +
  scale_y_continuous("Weight in Carat", 
                     sec.axis = sec_axis(~ . * 200, 
                                         name = "Weight in mg"))  
  


# Example Climograph

mydata <- data.frame(
  MonthID = 1:12,
  Temp_C = c(-4.3,-4.2,0.7,5.5,11.4,12.4,14.9,12.4,12.6,6.7,1.5,-3.4),
  Precip_mm = c(79,46,27,51,63,75,71,99,84,94,63,65))

ylim.prim <- c(0, 180)   # Precipitation in mm
ylim.sec <- c(-6, 18)    # Temperature in Celsius

mydiffs <- diff(ylim.prim)/diff(ylim.sec)
diffmulti <- mydiffs*(ylim.prim[1] - ylim.sec[1])

ggplot(mydata, aes(MonthID, Precip_mm)) +
  geom_col() +
  geom_line(aes(y = diffmulti + Temp_C*mydiffs),
            color = "red", lwd = 2.5) +
  scale_y_continuous("Precipitation",
                     sec.axis = sec_axis(~ (. - diffmulti)/mydiffs,
                                         name = "Temperature")) +
  scale_x_continuous("Month", breaks = 1:12) +
  ggtitle("Climograph of Monthly Averages")


## Using and Changing Plot Themes in ggplot2

# Applying themes at different levels
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  ggtitle("This Is A Main Title") +
  theme(title = element_text(face = "bold"))

ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  ggtitle("This Is A Main Title") +
  theme(plot.title = element_text(face = "bold"))

# Rotating
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  ggtitle("This Is A Main Title") +
  theme(plot.title = element_text(angle = 90))

# Center alignment
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  ggtitle("This Is A Main Title") +
  theme(plot.title = element_text(hjust = 0.5,
                                  vjust = 1))


# Using units for theme arguments
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  theme(axis.ticks.length = unit(7, "pt"))

# Unit with the size of the top, right, bottom, and left margins
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() + xlab("") + ylab("") +
  theme(plot.margin = unit(c(17, 33, 2, 15), "pt"))

# Metric unit
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() + xlab("") + ylab("") +
  theme(plot.margin = unit(c(17, 33, 2, 15), "mm"))


# Modifying the background grid system
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  theme(panel.grid = element_line(color = "red", 
                                  size = 2, 
                                  linetype = 3))

# Modifying the background color
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_blank() +
  theme(plot.background = element_rect(fill = "blue"),
        panel.background = element_rect(fill = "green", 
                                        color = "red",
                                        size = 4))


  
  
  


