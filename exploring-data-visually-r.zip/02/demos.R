

## Module: Using Visualizations for Exploratory Analysis

# Comparison of Plot Systems
# Dataset diamonds from ggplot2
library(ggplot2)

plot(diamonds$price,
     diamonds$carat,
     main = "Diamond Prices By Weight")

library(lattice)
xyplot(carat ~ price | color,
       data = diamonds,
       main = "Diamond Prices By Weight",
       type = c("p","r"))

library(ggplot2)
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point(shape=1) +   
  geom_smooth(method=lm) +
  ggtitle("Diamond Prices By Weight")


## Module: Visualizing Distributions

# Histograms

hist(diamonds$price)
hist(diamonds$price, breaks = 10)
hist(diamonds$price, freq = F)
hist(diamonds$price, col = diamonds$cut)

library(lattice)

histogram(~ price, data = diamonds)
histogram(~ price | cut, data = diamonds)

densityplot(~ price | cut, data = diamonds,
            plot.points = FALSE, ref = TRUE)

densityplot(~ price, data = diamonds,
            groups = cut,
            plot.points = FALSE, ref = TRUE,
            auto.key = list(columns = 3))


library(ggplot2)

ggplot(diamonds, aes(x=price)) +
  geom_histogram()

ggplot(diamonds, aes(x=price)) +
  geom_density()

ggplot(diamonds, aes(x=price)) +
  geom_histogram(aes(y=..density..),
                 binwidth=1000,
                 colour="black",
                 fill="white") +
  geom_density(alpha=.25, fill="#FF6666")

# QQ plots

qqnorm(diamonds$price)
x = rnorm(40000)
qqnorm(x)
qqline(x)

qqmath( ~ price, data = diamonds)
hist(diamonds$price)
ggplot(diamonds, aes(sample = price)) +
  stat_qq()


# Boxplots

boxplot(price ~ cut, diamonds)
means <- tapply(diamonds$price,
                diamonds$cut, mean)
points(means, col = "red")


bwplot(color ~ price | cut, data = diamonds)
bwplot(color ~ carat | cut, data = diamonds)

ggplot(diamonds, aes(color, price)) + 
  geom_boxplot() +
  coord_flip() +
  facet_wrap(~ cut)



## Module: Working with Categorical Data and Using It for Clustering Charts

# Scatterplots

plot(diamonds$price, diamonds$carat)
abline(lm(carat ~ price, data = diamonds))

plot(diamonds$price, diamonds$carat,
     col = diamonds$cut, pch = 20,
     cex = 0.75, bty = "l")

par()


plot(diamonds$price, diamonds$carat, 
     col=kmeans(diamonds[,c(8,9,10)],5)$cluster)

library(lattice)
xyplot(carat ~ price, data = diamonds,
       groups = color,
       auto.key = list(columns = 7),
       type = c("p","r"),
       cex = 0.5, pch = 20)


xyplot(carat ~ price | cut, data = diamonds,
       groups = color,
       auto.key = list(columns = 7),
       type = c("p","r"),
       cex = 0.5, pch = 20)


library(ggplot2)
ggplot(diamonds, aes(x=price, y=carat)) +
  geom_point(shape=1) +   
  geom_smooth(method=lm) +
  ggtitle("Diamond Prices By Weight")



ggplot(diamonds, aes(x=price, y=carat, color=cut)) + 
  geom_point(shape=19, position=position_jitter(width=1, height=.5)) +
  scale_colour_hue(l=50) + 
  geom_smooth(method=lm, se=FALSE, fullrange=TRUE)


ggplot(diamonds, aes(x=price, y=carat, color=cut)) + 
  geom_point(shape=19, alpha = 0.2) +
  scale_colour_hue(l=50) + 
  geom_smooth(method=lm,   
              se=FALSE,    
              fullrange=TRUE)


# Barcharts

summary(diamonds)
counts <- table(diamonds$cut, diamonds$color)
counts
barplot(counts, legend = rownames(counts))

barplot(counts, legend = rownames(counts),
        horiz = TRUE)


mydf = as.data.frame(ftable(diamonds$cut,
                            diamonds$color,
                            diamonds$clarity))
head(mydf)
barchart(Var3 ~ Freq | Var2,
         groups = Var1, mydf, stack = TRUE,
         auto.key = list(columns = 5))


 
ggplot(mydf, aes(x = Var3, y = Freq,
                 fill = Var1)) + 
  geom_bar(stat = 'identity',
           position = 'stack') +
  facet_grid(~ Var2)


# Adjusting the labels on the X axis

ggplot(mydf, aes(x = Var3, y = Freq, fill = Var1)) +
  geom_bar(stat = 'identity', position = 'stack') +
  facet_grid(~ Var2) + xlab("") +
  theme(axis.text.x = element_text(angle = 90,
                                   hjust = 1,
                                   size = 8))

# Creating the bar chart without a contingency table
ggplot(diamonds, aes(x = clarity, fill = cut)) +
  geom_bar(stat = 'count', position = 'stack') +
  facet_grid(~ color) + xlab("") +
  theme(axis.text.x = element_text(angle = 90,
                                   hjust = 1,
                                   size = 8))















